package test.java.test.java;

import org.junit.runner.RunWith;
import org.testng.annotations.Test;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;


@Test
@RunWith(Cucumber.class)
@CucumberOptions(features="src/test/test.java.test.java/page.feature", glue={"test.java.test.java.stepdef"})
public class runnerclass {

	
		

}


