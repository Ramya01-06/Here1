package test.java.test.java;


import test.Page_load;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;



public class stepdef extends Page_load{
	
	@Given("^I open a browser$")
	public void openBrowser(){
		System.out.println("Firefox browser gets loaded");
		Page_load.page();
	}
	

	@Then("^I navigate to \"(.*?)\"$")
	public void i_navigate_to(String arg1) throws Throwable {
		System.out.println("I move to Documentation page");
	}

	@Then("^I validate that the Documentation page should be displayed\\.$")
	public void i_validate_that_the_Documentation_page_should_be_displayed() throws Throwable {
		System.out.println("I am in documentation page");
	}
	
	@Given("I click on given Licensing & Terms FAQs")
public void i_click_on_given_Licensing_Terms_FAQs() {
		System.out.println("I click on given Licensing & Terms FAQs");
}

@Then("the respective home page opens")
public void the_respective_home_page_opens() {
    System.out.println("the respective home page opens");
}

@Given("I click on given get started for free")
public void i_click_on_given_get_started_for_free() {
    System.out.println("I click on given get started for free");
}

@Given("I click on given JS")
public void i_click_on_given_JS() {
    System.out.println("I click on given JS");
}

@Given("I click on given ANDROID STARTER")
public void i_click_on_given_ANDROID_STARTER() {
    System.out.println("I click on given ANDROID STARTER");
}

@Given("I click on given ANDROID PREMIUM")
public void i_click_on_given_ANDROID_PREMIUM() {
    System.out.println("I click on given ANDROID PREMIUM");
}

@Given("I click on given IOS STARTER")
public void i_click_on_given_IOS_STARTER() {
    System.out.println("I click on given IOS STARTER");
}

@Given("I click on given IOS PREMIUM")
public void i_click_on_given_IOS_PREMIUM() {
    System.out.println("I click on given IOS PREMIUM");
}

@Given("I click on given REST")
public void i_click_on_given_REST() {
    System.out.println("I click on given REST");
}

@Given("I click on given MOBILE SDK")
public void i_click_on_given_MOBILE_SDK() {
    System.out.println("I click on given MOBILE SDK");
}

@Given("I click on given WEB SDK")
public void i_click_on_given_WEB_SDK() {
    System.out.println("I click on given WEB SDK");
}

@Given("I click on given DOCUMENTATION")
public void i_click_on_given_DOCUMENTATION() {
    System.out.println("I click on given DOCUMENTATION");
}

@Given("I click on given OVERVIEW")
public void i_click_on_given_OVERVIEW() {
    System.out.println("I click on given OVERVIEW");
}

@Given("I click on given Download PDF documentation")
public void i_click_on_given_Download_PDF_documentation() {
    System.out.println("I click on given Download PDF documentation");
}

@Given("I click on given Contact us")
public void i_click_on_given_Contact_us() {
    System.out.println("I click on given Contact us");
}

@Given("I click on given Get a free API key")
public void i_click_on_given_Get_a_free_API_key() {
    System.out.println("I click on given Get a free API key");
}

@Given("I click on given See all")
public void i_click_on_given_See_all() {
    System.out.println("I click on given See all");
}

@Given("I click on given Maps")
public void i_click_on_given_Maps() {
    System.out.println("I click on given Maps");
}

@Given("I click on given Geocoding and Search")
public void i_click_on_given_Geocoding_and_Search() {
    System.out.println("I click on given Geocoding and Search");
}

@Given("I click on given Routing and Navigation")
public void i_click_on_given_Routing_and_Navigation() {
    System.out.println("I click on given Routing and Navigation");
}

@Given("I click on given Fleet Telematics")
public void i_click_on_given_Fleet_Telematics() {
    System.out.println("I click on given Fleet Telematics");
}

@Given("I click on given XYZ")
public void i_click_on_given_XYZ() {
    System.out.println("I click on given XYZ");
}

@Given("I click on given JavaScript")
public void i_click_on_given_JavaScript() {
    System.out.println("I click on given JavaScript");
}

@Given("I click on given Mobile SDKs")
public void i_click_on_given_Mobile_SDKs() {
    System.out.println("I click on given Mobile SDKs");
}

@Given("I click on given Open Location Platform")
public void i_click_on_given_Open_Location_Platform() {
    System.out.println("I click on given Open Location Platform");
}

@Given("I click on given Tracking")
public void i_click_on_given_Tracking() {
    System.out.println("I click on given Tracking");
}

@Given("I click on given Advertising Data Services")
public void i_click_on_given_Advertising_Data_Services() {
    System.out.println("I click on given Advertising Data Services");
}

@Given("I click on given Automotive")
public void i_click_on_given_Automotive() {
    System.out.println("I click on given Automotive");
}

@Given("I click on given Indoor Positioning")
public void i_click_on_given_Indoor_Positioning() {
    System.out.println("I click on given Indoor Positioning");
}

@Given("I click on given HERE Student Sample Map Data")
public void i_click_on_given_HERE_Student_Sample_Map_Data() {
    System.out.println("I click on given HERE Student Sample Map Data");
}

@Given("I click on given here.com")
public void i_click_on_given_here_com() {
    System.out.println("I click on given here.com");
}

@Given("I click on given Terms")
public void i_click_on_given_Terms() {
    System.out.println("I click on given Terms");
}

@Given("I click on given Privacy Settings")
public void i_click_on_given_Privacy_Settings() {
   System.out.println("I click on given Privacy Settings");
}

@Given("I click on given Privacy Policy")
public void i_click_on_given_Privacy_Policy() {
    System.out.println("I click on given Privacy Policy");
}

@Given("I click on given Cookie Policy")
public void i_click_on_given_Cookie_Policy() {
    System.out.println("I click on given Cookie Policy");
}

@Given("I click on given FAQs")
public void i_click_on_given_FAQs() {
    System.out.println("I click on given FAQs");
}

@Given("I click on given Contact Us")
public void i_click_on_given_Contact_Us() {
    System.out.println("I click on given Contact Us");
}

@Given("I click on given Sitemap")
public void i_click_on_given_Sitemap() {
    System.out.println("I click on given Sitemap");
}

@Given("I click on given HERE Developer Blog")
public void i_click_on_given_HERE_Developer_Blog() {
    System.out.println("I click on given HERE Developer Blog");
}

@Given("I click on given Twitter")
public void i_click_on_given_Twitter() {
    System.out.println("I click on given Twitter");
}

@Given("I click on given Stack Overflow")
public void i_click_on_given_Stack_Overflow() {
    System.out.println("I click on given Stack Overflow");
}

@Given("I click on given GitHub")
public void i_click_on_given_GitHub() {
    System.out.println("I click on given GitHub");
}

@Given("I click on given HERE Developer Newsletter")
public void i_click_on_given_HERE_Developer_Newsletter() {
    System.out.println("I click on given HERE Developer Newsletter");
}

}

